//test
/*
	test
*/
//EventHandler 
function hello()
{
	alert("You clicked");
}
function hello1()
{
	document.write("You clicked");
}

function EventHandler()
{
	alert("Event handler");
}
function EventHandler1()
{
	alert("Event handler out");
}

//Arithematic operations
function ari()
{
	var a=33;
	var b=14;
	var c="Test";
	var br="<br/>";
	var res=a+b
	document.write("a="+a+br+"b="+b+br)
	document.write(a+"+"+b+"="+res+br);
	res=a-b
	document.write(a+"-"+b+"="+res+br);	
	document.write(++a+br);
	document.write("a="+a+br+"b="+b+br)
	res=a/b
	document.write(a+"/"+b+"="+res+br);
	document.write(--b+br);
	document.write("a="+a+br+"b="+b+br)	
	res=a*b
	document.write(a+"*"+b+"="+res+br);	
	res=a+c;
	document.write("a+c="+res+br+br);
	document.write("a is "+typeof a+br+"b is "+typeof b+br+"c is "+typeof c+br);
	document.write(typeof c=="string"?"c is string":"c in numeric");
}
function aris(val,b)
{
	var s1;
	var s2;
	var res;
	var a;
	if(b==1){
		s1=parseInt(val);
	}else if(b==2&&val<10){
		s2=parseInt(val);
	}else if(val==12){
		res=s1+s2;
		document.write(parseInt(res));
	}
	
	
}
