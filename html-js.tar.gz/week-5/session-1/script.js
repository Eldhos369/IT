function one(val){
	var count=0;
	var br="</br>";
	document.write("STARTING LOOP"+br);
	do{
		document.write("count :"+count+br);
		count++;
	}while(count<val);
	document.write("LOOP ENDED"+br);
	var vl=confirm("Do you want to find the sum of "+count);
	if(vl==true){
		two(count);
	}else{
		document.write("Finish");
	}
}
function two(val){
	var count=0;
	var s=0
	var br="</br>";
	while(count<val){
		s=s+count;
		count++;
	}
	alert("sum of "+val+" No. : "+ s);
}

function three(){
	var s1=prompt("Enter num 1:");
	var s2=prompt("Enter num 2:");
	var s=parseInt(s1)+parseInt(s2);	
	alert(s1+" + "+s2+" = "+s)
}
function four()
{
	var s1=parseInt(prompt("Enter number : "));
	var i=2;
	var f=0;
	while(i<=s1/2){
		if(s1%i==0)
		{
			f=1;
		}
		i++;
	}
	if(f==1){
		alert("Given number not prime");
	}else{
		alert("Given number is prime");
	}
	
}
