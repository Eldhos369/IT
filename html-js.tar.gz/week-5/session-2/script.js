var car={
	type:"Fiat",
	model:"500",
	color:"white",
	fullmodel:function(){
		return this.type+" "+this.model;
	}};

var car1={
	type:"Fiat",
	model:"500",
	color:"white",
	fullmodel:function(){
		return this.type+" "+this.model;
	},
	time:{
		year:"2000",
		month:"jan"
	}};

function two(){	
	var person=new Object();
	person.fname="Eldhos ";
	person.lname=" Aji";
	person.fullname=function(){
		document.write(person.fname+" "+person.lname);
	};
	person.fullname();
}

function one(){
	document.write(car1.type+"</br>");
	document.write(car1["model"]+"</br>");
	document.write(car.color+"</br>");
	document.write(car1.time.year+"</br>"+car1.time.month+"</br>");
	document.write(car1.fullmodel()+"</br>");
	two();
}
