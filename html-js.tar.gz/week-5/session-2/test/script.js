var a;
var b;
var s=0;
var as;
var res;
function one(value){
	if(s==0&&value<=9){
		a=parseInt(value);
		s=1;
	}else if(s==1&&value<=9){
		b=parseInt(value);
	}else{
		as=parseInt(value);
	}
}

function ass(){
	switch(as){
		case 12:
			res=a+b;
			break;
		case 13:
			res=a-b;
			break;
		case 14:
			res=a*b;
			break;
				
	}
	document.write(res);
}
